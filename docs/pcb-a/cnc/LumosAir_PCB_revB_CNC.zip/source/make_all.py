import pickle, math, os, json
import ezdxf
from shapely.geometry import Point, Polygon, box, LineString
from shapely.ops import unary_union
from shapely import affinity
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPoly
import numpy as np
import geom, board, finalize
from parts import parts, FIXED

OUT = '/home/claude/pcb/out'
os.makedirs(OUT, exist_ok=True)
Y0 = 121.977
SHEET = (200.0, 150.0)
PLACE = {'bottom': (5.0, 5.0), 'top': (91.0, 5.0), 'carrier1': (177.0, 5.0), 'carrier2': (177.0, 25.0)}


def to_cu(g):
    """world top-view -> copper-side view, board-local (mirror X)"""
    return affinity.affine_transform(g, [-1, 0, 0, 1, 40.5, -Y0])


def pt_cu(x, y):
    return (40.5 - x, y - Y0)


# ---------------- bottom board ----------------
P = parts()
R = pickle.load(open('/home/claude/pcb/bottom_route.pkl', 'rb'))
traces = R['traces']
brd, cuts, holes = board.bottom_board()
pads = []
for ref, pl in P.items():
    for p in pl:
        net = p[5] or f'NC_{ref}_{p[6]}'
        drill = p[4] if p[0] == 'tht' else None
        pads.append((board.pad_geom(p), net, drill, (p[1], p[2])))
bot = finalize.build(brd, pads, traces, board.TRACE_W, board.CLR)
print('BOTTOM DRC:', bot['report'] or 'clean')
print('  GND pads not on main pour:', bot['gnd_islands'], ' pour pieces:', bot['pour_parts'], ' dropped islands:', bot['dropped_islands'])
drills_bot = {}
for g, net, d, c in pads:
    if d:
        drills_bot.setdefault(d, []).append(c)
for x, y in geom.MOUNT_HOLES + geom.BRACKET_SCREWS:
    drills_bot.setdefault(2.7, []).append((x, y))

# ---------------- top board ----------------
top = Polygon(geom.TOP_OUTLINE)
x0, x1, y0, y1 = geom.FLANGE_NOTCH
top = top.difference(box(x0, y0, x1, y1))
drills_top = {2.7: list(geom.MOUNT_HOLES)}
rings = []
for name, (d, pts) in geom.TOP_HOLES.items():
    if d >= 5:
        continue
    drills_top.setdefault(d, []).extend(pts)
inside_top = [Point(35.0, 177.5).buffer(3.5, 48)]
ring_r = {2.7: 3.6, 3.4: 4.0, 2.2: 3.0}
for d, pts in drills_top.items():
    for x, y in pts:
        rings.append(Point(x, y).buffer(ring_r[d], 48).difference(Point(x, y).buffer(d / 2 - 0.2, 32)))
rings.append(Point(35.0, 177.5).buffer(4.5, 48).difference(Point(35.0, 177.5).buffer(3.3, 48)))
top_remove = unary_union(rings).intersection(top)
top_cut = top.difference(unary_union(inside_top + [Point(x, y).buffer(d / 2, 32) for d, pts in drills_top.items() for x, y in pts]))


# ---------------- XGZP carrier (copper view, local u/v, origin bottom-left) ----------------
def carrier():
    W, H = 14.0, 14.3
    outline = box(0, 0, W, H)
    vs = 8.3
    rows = {'top': vs + 4.6, 'bot': vs - 4.6}
    us = [3.19, 5.73, 8.27, 10.81]
    sop = []   # (geom, net)
    top_nets = ['GND', 'SCL', 'SDA', 'NC5']      # p8 p7 p6 p5
    bot_nets = ['NC1', 'VDD', 'NC3', 'NC4']      # p1 p2 p3 p4
    for u, n in zip(us, top_nets):
        sop.append((box(u - 0.4, rows['top'] - 0.7, u + 0.4, rows['top'] + 0.7), n))
    for u, n in zip(us, bot_nets):
        sop.append((box(u - 0.4, rows['bot'] - 0.7, u + 0.4, rows['bot'] + 0.7), n))
    hdr = [(box(u - 0.8, 0.0, u + 0.8, 1.8), n) for u, n in zip(us, ['GND', 'VDD', 'SCL', 'SDA'])]
    w = 0.4
    tr = {
        'VDD': [LineString([(5.73, rows['bot']), (5.73, 0.9)])],
        'SCL': [LineString([(5.73, rows['top']), (7.0, rows['top'] - 1.2), (7.0, 2.4), (8.27, 2.4), (8.27, 0.9)])],
        'SDA': [LineString([(8.27, rows['top']), (9.54, rows['top'] - 1.2), (9.54, 2.4), (10.81, 2.4), (10.81, 0.9)])],
        'GND': [LineString([(3.19, rows['top']), (1.3, rows['top'] - 1.5), (1.3, 2.4), (3.19, 2.4), (3.19, 0.9)])],
    }
    cpads = [(g, n, None, None) for g, n in sop + hdr]
    res = finalize.build(outline, cpads, tr, w, 0.3, gnd='GND', pullback=0.3, sliver=0.2)
    return outline, res, sop, hdr, tr


c_outline, cres, sop, hdr, ctr = carrier()
print('CARRIER DRC:', cres['report'] or 'clean')


# ---------------- DXF writer ----------------
def add_poly(msp, poly, layer, dx=0, dy=0):
    for ring in [poly.exterior] + list(poly.interiors):
        pts = [(x + dx, y + dy) for x, y in ring.coords]
        msp.add_lwpolyline(pts, close=True, dxfattribs={'layer': layer})


def add_geom(msp, g, layer, dx=0, dy=0):
    for p in finalize.as_polys(g):
        add_poly(msp, p, layer, dx, dy)


LAYERS = {'OUTLINE': 7, 'INSIDE_CUTS': 1, 'COPPER_REMOVE': 3, 'COPPER_KEEP_ref': 8, 'LABELS_ref': 5,
          'DRILL_0.9': 4, 'DRILL_1.0': 4, 'DRILL_2.2': 6, 'DRILL_2.7': 6, 'DRILL_3.4': 6}


def new_doc():
    doc = ezdxf.new('R2010', setup=True)
    doc.units = ezdxf.units.MM
    for n, c in LAYERS.items():
        doc.layers.add(n, color=c)
    return doc


def emit_bottom(msp, dx, dy, labels=True):
    b = to_cu(brd)
    # outer outline as OUTLINE; interior rings that are slots -> INSIDE_CUTS, drilled holes excluded (they are drills)
    outer = Polygon(to_cu(Polygon(geom.BOTTOM_OUTLINE)).exterior.coords)
    x0, x1, y0, y1 = geom.FLANGE_NOTCH
    outer = outer.difference(to_cu(box(x0, y0, x1, y1)))
    add_geom(msp, outer, 'OUTLINE', dx, dy)
    for name, (a, bb, c, d) in geom.BOTTOM_SLOTS.items():
        add_geom(msp, to_cu(box(a, c, bb, d)), 'INSIDE_CUTS', dx, dy)
    add_geom(msp, to_cu(bot['remove']).difference(unary_union([to_cu(box(a, c, bb, d)) for (a, bb, c, d) in geom.BOTTOM_SLOTS.values()])), 'COPPER_REMOVE', dx, dy)
    add_geom(msp, to_cu(bot['copper']), 'COPPER_KEEP_ref', dx, dy)
    for d, pts in drills_bot.items():
        for x, y in pts:
            X, Y = pt_cu(x, y)
            msp.add_circle((X + dx, Y + dy), d / 2, dxfattribs={'layer': f'DRILL_{d:.1f}'})
    if labels:
        msp.add_text('PCB-A BOTTOM  copper side up (mirrored)', height=2.0,
                     dxfattribs={'layer': 'LABELS_ref'}).set_placement((dx + 2, dy + 107))


def emit_top(msp, dx, dy, labels=True):
    outer = to_cu(top)
    add_geom(msp, Polygon(outer.exterior.coords), 'OUTLINE', dx, dy)
    for g in inside_top:
        add_geom(msp, to_cu(g), 'INSIDE_CUTS', dx, dy)
    add_geom(msp, to_cu(top_remove), 'COPPER_REMOVE', dx, dy)
    for d, pts in drills_top.items():
        for x, y in pts:
            X, Y = pt_cu(x, y)
            msp.add_circle((X + dx, Y + dy), d / 2, dxfattribs={'layer': f'DRILL_{d:.1f}'})
    if labels:
        msp.add_text('TOP BOARD  copper side up (mirrored)', height=2.0,
                     dxfattribs={'layer': 'LABELS_ref'}).set_placement((dx + 2, dy + 107))


def emit_carrier(msp, dx, dy, labels=True):
    add_geom(msp, c_outline, 'OUTLINE', dx, dy)
    add_geom(msp, cres['remove'], 'COPPER_REMOVE', dx, dy)
    add_geom(msp, cres['copper'], 'COPPER_KEEP_ref', dx, dy)
    if labels:
        msp.add_text('XGZP', height=1.2, dxfattribs={'layer': 'LABELS_ref'}).set_placement((dx, dy + 14.8))


for name, fn in (('pcbA_bottom', emit_bottom), ('pcb_top', emit_top), ('xgzp_carrier', emit_carrier)):
    doc = new_doc(); fn(doc.modelspace(), 0, 0); doc.saveas(f'{OUT}/{name}_coppersideup.dxf')
doc = new_doc(); msp = doc.modelspace()
msp.add_lwpolyline([(0, 0), (SHEET[0], 0), SHEET, (0, SHEET[1])], close=True, dxfattribs={'layer': 'LABELS_ref'})
emit_bottom(msp, *PLACE['bottom']); emit_top(msp, *PLACE['top'])
emit_carrier(msp, *PLACE['carrier1']); emit_carrier(msp, *PLACE['carrier2'])
doc.saveas(f'{OUT}/sheet_200x150_one_node.dxf')

# stats
def area(g): return sum(p.area for p in finalize.as_polys(g))
stats = {'bottom_remove_mm2': round(area(bot['remove']), 1), 'top_remove_mm2': round(area(top_remove), 1),
         'carrier_remove_mm2': round(area(cres['remove']), 1),
         'drills_bottom': {str(k): len(v) for k, v in drills_bot.items()},
         'drills_top': {str(k): len(v) for k, v in drills_top.items()}}
print(json.dumps(stats))
pickle.dump({'bot': bot, 'top_remove': top_remove, 'top': top, 'cres': cres, 'drills_bot': drills_bot, 'drills_top': drills_top}, open(f'{OUT}/geom.pkl', 'wb'))

# ---------------- previews ----------------
def draw(ax, g, **kw):
    for q in finalize.as_polys(g):
        ax.add_patch(MPoly(np.array(q.exterior.coords), closed=True, **kw))
        for i in q.interiors:
            ax.add_patch(MPoly(np.array(i.coords), closed=True, fc='white', ec=kw.get('ec', 'none'), lw=kw.get('lw', 0)))

def show(ax, outline_g, copper_g, drills, dx=0, dy=0):
    draw(ax, affinity.translate(outline_g, dx, dy), fc='#3a2a1a', ec='k', lw=0.5)
    draw(ax, affinity.translate(copper_g.intersection(outline_g), dx, dy), fc='#d88f45', ec='none')
    for d, pts in drills.items():
        for x, y in pts:
            X, Y = pt_cu(x, y)
            ax.add_patch(plt.Circle((X + dx, Y + dy), d / 2, fc='white', ec='k', lw=0.3))

top_copper = top_cut.difference(top_remove)
fig, ax = plt.subplots(figsize=(16, 12))
ax.add_patch(MPoly(np.array([(0, 0), (200, 0), (200, 150), (0, 150)]), closed=True, fc='#f4f4f4', ec='k'))
show(ax, to_cu(brd), to_cu(bot['copper']), drills_bot, *PLACE['bottom'])
show(ax, to_cu(top_cut), to_cu(top_copper), drills_top, *PLACE['top'])
for key in ('carrier1', 'carrier2'):
    show(ax, c_outline, cres['copper'], {}, *PLACE[key])
ax.set_xlim(-2, 202); ax.set_ylim(-2, 152); ax.set_aspect('equal')
ax.set_title('One node on a 200 x 150 sheet, COPPER SIDE UP (orange = copper kept, dark = copper milled away, white = drilled / cut through)')
plt.savefig(f'{OUT}/sheet_preview.png', dpi=110, bbox_inches='tight')

fig, ax = plt.subplots(figsize=(11, 14))
show(ax, to_cu(brd), to_cu(bot['copper']), drills_bot)
ax.set_xlim(-1, 82); ax.set_ylim(-1, 107); ax.set_aspect('equal')
ax.set_title('PCB-A bottom board - COPPER SIDE as milled (mirror image of the component side)')
plt.savefig(f'{OUT}/pcbA_bottom_copper_preview.png', dpi=140, bbox_inches='tight')

fig, ax = plt.subplots(figsize=(5, 5))
show(ax, c_outline, cres['copper'], {})
for g, n in sop:
    c = g.centroid; ax.text(c.x, c.y, n, fontsize=5, ha='center', va='center', rotation=90)
for g, n in hdr:
    c = g.centroid; ax.text(c.x, c.y - 0.5, n, fontsize=5, ha='center', va='top')
ax.set_xlim(-0.5, 14.5); ax.set_ylim(-1.5, 15); ax.set_aspect('equal')
ax.set_title('XGZP carrier - copper side (sensor side)', fontsize=9)
plt.savefig(f'{OUT}/xgzp_carrier_preview.png', dpi=200, bbox_inches='tight')
