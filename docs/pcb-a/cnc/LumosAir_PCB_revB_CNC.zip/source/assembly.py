import pickle
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPoly, Rectangle, Circle
from matplotlib.backends.backend_pdf import PdfPages
from shapely.geometry import box
import board, geom, finalize
from parts import parts

P = parts()
R = pickle.load(open('/home/claude/pcb/bottom_route.pkl', 'rb'))
G = pickle.load(open('/home/claude/pcb/out/geom.pkl', 'rb'))
brd, _, _ = board.bottom_board()

LABEL = {  # pad label overrides (ref,pin) -> text
}
fig, ax = plt.subplots(figsize=(12.5, 16))


def draw(g, **kw):
    for q in finalize.as_polys(g):
        ax.add_patch(MPoly(np.array(q.exterior.coords), closed=True, **kw))
        for i in q.interiors:
            ax.add_patch(MPoly(np.array(i.coords), closed=True, fc='white', ec=kw.get('ec', 'k'), lw=0.4))


draw(brd, fc='#f3e3c8', ec='k', lw=0.8)
# traces seen through the board
for net, ls in R['traces'].items():
    for l in ls:
        x, y = l.xy
        ax.plot(x, y, '-', color='#c9a27a', lw=1.6, solid_capstyle='round', zorder=1)
# module / part outlines on the component side
outl = [
    ('U6 TCA9548A breakout\n(check pin labels!)', (-15.25, 123.3, 30.5, 17.8), '#3b6fd4'),
    ('U7 GY-BME280', (16.6, 131.0, 13.0, 10.5), '#8a3fb3'),
    ('J2 JST-PH 5', (23.55, 175.25, 11.9, 4.5), '#444444'),
    ('OK1 PC817', (26.8, 193.96, 6.5, 4.6), '#222222'),
    ('U4 bin XGZP\ncarrier (edge)', (-5.6, 141.1, 2.2, 14.0), '#1c7c3c'),
    ('U5 run XGZP\ncarrier (edge)', (-5.6, 199.6, 2.2, 14.0), '#1c7c3c'),
]
for name, (x, y, w, h), c in outl:
    ax.add_patch(Rectangle((x, y), w, h, fill=False, ec=c, lw=1.4, ls='-', zorder=3))
    ax.text(x + w / 2, y + h + 0.6, name, color=c, fontsize=7, ha='center', va='bottom', zorder=5)
for name, (a, b, c, d) in geom.BOTTOM_SLOTS.items():
    ax.text((a + b) / 2, (c + d) / 2, name.replace(' slot', '') + '\n(SDP810 on edge,\nthrough slot)', fontsize=7, ha='center', va='center', color='#7a5a00')
# pads
for ref, pl in P.items():
    for p in pl:
        if p[0] == 'tht':
            _, x, y, d, dr, net, pin = p
            fc = '#555555' if net == 'GND' else ('#b87333' if net else '#dddddd')
            ax.add_patch(Circle((x, y), d / 2, fc=fc, ec='k', lw=0.4, zorder=4))
            ax.add_patch(Circle((x, y), dr / 2, fc='white', ec='none', zorder=4))
        else:
            _, x, y, w, h, net, pin = p
            ax.add_patch(Rectangle((x - w / 2, y - h / 2), w, h, fill=False, ec='#b05000', lw=0.8, ls='--', zorder=4))
    xs = [p[1] for p in pl]; ys = [p[2] for p in pl]
    if pl[0][0] == 'smd':
        ax.text(np.mean(xs), np.mean(ys), ref, fontsize=5.5, ha='center', va='center', color='#b05000', zorder=6)
# landing labels
def lab(x, y, t, dx=0, dy=1.3, **kw):
    ax.text(x + dx, y + dy, t, fontsize=5.5, ha='center', va='bottom', zorder=6, color='navy', **kw)
for ref in ('L1', 'L2', 'L3', 'L5', 'J3', 'U4', 'U5', 'J2', 'U7'):
    for p in P[ref]:
        _, x, y, d, dr, net, pin = p
        t = f'{ref}\n{pin}' if ref not in ('J2',) else f'{pin}\n{net}'
        if ref in ('U4', 'U5', 'U7'):
            ax.text(x - 1.4 if ref != 'U7' else x + 1.3, y, f'{net if ref!="U5" else pin}', fontsize=5.5,
                    ha='right' if ref != 'U7' else 'left', va='center', color='navy', zorder=6)
        else:
            lab(x, y, t)
for k, p in enumerate(P['U6']):
    _, x, y, d, dr, net, pin = p
    ax.text(x, y + (-1.4 if y < 130 else 1.3), pin, fontsize=4.5, ha='center', va='top' if y < 130 else 'bottom',
            rotation=90, color='#3b6fd4', zorder=6)
for x, y in geom.MOUNT_HOLES + geom.BRACKET_SCREWS:
    ax.add_patch(Circle((x, y), 1.35, fc='white', ec='k', lw=0.6, zorder=4))
ax.set_xlim(-42, 42); ax.set_ylim(120, 230); ax.set_aspect('equal')
ax.set_title('PCB-A rev B bottom board - COMPONENT SIDE (parts on this side; traces & SMD parts are on the underside, shown faint / dashed)\n'
             'USB end at the bottom, antenna end at the top, +X wall on the right', fontsize=9)
ax.set_xlabel('mm (box X)'); ax.set_ylabel('mm (box Y)')
plt.savefig('/home/claude/pcb/out/pcbA_assembly_component_side.png', dpi=160, bbox_inches='tight')
plt.savefig('/home/claude/pcb/out/pcbA_assembly_component_side.pdf', bbox_inches='tight')
print('ok')
