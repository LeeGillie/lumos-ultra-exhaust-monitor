"""Copper pour, DRC and machining geometry for a single-sided isolation-milled board."""
import math
from shapely.geometry import Point, Polygon, MultiPolygon, LineString, box
from shapely.ops import unary_union


def as_polys(g):
    if g is None or g.is_empty:
        return []
    if isinstance(g, Polygon):
        return [g]
    return [p for p in getattr(g, 'geoms', []) if isinstance(p, Polygon) and not p.is_empty]


def build(board_poly, pads, traces, trace_w, clr, gnd='GND', pullback=0.5, sliver=0.3,
          island_min_area=3.0, clear_rings=()):
    """pads: list of (geom, net, drill, (x,y)); traces: {net: [LineString]}.
    clear_rings: list of shapely polygons where copper must be fully removed (e.g. under nuts).
    Returns dict with net copper, pour, remove region, drc report."""
    net_cu = {}
    for g, net, drill, c in pads:
        net_cu.setdefault(net, []).append(g)
    for net, ls in traces.items():
        for l in ls:
            net_cu.setdefault(net, []).append(l.buffer(trace_w / 2, 12))
    net_cu = {n: unary_union(v) for n, v in net_cu.items()}

    # --- DRC: spacing between different nets (GND pads included, pour handled separately)
    report = []
    names = list(net_cu)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = net_cu[names[i]], net_cu[names[j]]
            d = a.distance(b)
            if d < clr - 0.02:
                report.append(f'SPACING {names[i]} <-> {names[j]}: {d:.3f} mm')
    for n, g in net_cu.items():
        if not g.within(board_poly.buffer(1e-6)):
            report.append(f'OFFBOARD copper on {n}')
        dedge = g.distance(board_poly.exterior)
        for hole in board_poly.interiors:
            dedge = min(dedge, g.distance(LineString(hole.coords)))
        if dedge < 0.35:
            report.append(f'EDGE {n}: {dedge:.3f} mm from a cut edge')

    # --- pour
    copper_area = board_poly.buffer(-pullback, join_style=2)
    signal = unary_union([g for n, g in net_cu.items() if n != gnd])
    pour = copper_area.difference(signal.buffer(clr, 12))
    for r in clear_rings:
        pour = pour.difference(r)
    pour = pour.buffer(-sliver, join_style=1).buffer(sliver, join_style=1)   # drop slivers < 2*sliver
    gnd_cu = net_cu.get(gnd)
    if gnd_cu is not None:
        pour = unary_union([pour, gnd_cu])
    parts = as_polys(pour)
    # connectivity of GND pads
    gpads = [(g, c) for g, n, d, c in pads if n == gnd]
    comp_of = []
    for g, c in gpads:
        k = next((i for i, p in enumerate(parts) if p.intersects(g)), None)
        comp_of.append(k)
    main = max(set(k for k in comp_of if k is not None), key=lambda k: parts[k].area) if gpads else None
    isolated = [c for (g, c), k in zip(gpads, comp_of) if k != main]
    keep = []
    dropped = 0
    for i, p in enumerate(parts):
        has_gnd = i in comp_of
        if has_gnd or p.area >= island_min_area:
            keep.append(p)
        else:
            dropped += 1
    pour = unary_union(keep)
    copper = unary_union([pour] + [g for n, g in net_cu.items() if n != gnd])
    remove = board_poly.difference(copper)
    # minimum width of the removal (tool must fit): erode by 0.07 and see what vanishes
    return dict(net_cu=net_cu, pour=pour, copper=copper, remove=remove, report=report,
                gnd_islands=isolated, pour_parts=len(as_polys(pour)), dropped_islands=dropped)
