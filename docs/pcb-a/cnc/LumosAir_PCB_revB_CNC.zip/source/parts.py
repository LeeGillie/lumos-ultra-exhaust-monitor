"""PCB-A (bottom board) rev B: hub layout around the mux.
World XY, top (component-side) view, mm.

THT pad: ('tht', x, y, pad_dia, drill, net, pin)
SMD pad (copper side): ('smd', x, y, w, h, net, pin)

Channel map (rev B):  ch0 pitot, ch1 run_in (fan box: fan_in), ch2 bin, ch3 cyc_dp, ch4 encl, ch5-7 spare.
"""
MUX_PINMAP_OUTER = ['VIN', 'GND', 'SDA', 'SCL', 'RST', 'A0', 'A1', 'A2', 'SD7', 'SC7', 'SD6', 'SC6']   # y 124.58, x -13.97..+13.97
MUX_PINMAP_INNER = ['SD0', 'SC0', 'SD1', 'SC1', 'SD2', 'SC2', 'SD3', 'SC3', 'SD4', 'SC4', 'SD5', 'SC5']  # y 139.82
MUX_NET = {'VIN': '+3V3', 'GND': 'GND', 'SDA': 'SDA', 'SCL': 'SCL', 'RST': None, 'A0': None, 'A1': None, 'A2': None,
           'SD0': 'SDA0', 'SC0': 'SCL0', 'SD1': 'SDA1', 'SC1': 'SCL1', 'SD2': 'SDA2', 'SC2': 'SCL2', 'SD3': 'SDA3',
           'SC3': 'SCL3', 'SD4': 'SDA4', 'SC4': 'SCL4', 'SD5': None, 'SC5': None, 'SD6': None, 'SC6': None,
           'SD7': None, 'SC7': None}
# RST and A0-A2 are left open: the breakout pulls RST up and A0-A2 down itself (address 0x70).

P254 = (1.8, 1.0)
PPH = (1.6, 0.9)
PWIRE = (1.8, 1.0)
MUX_X = [-13.97 + 2.54 * k for k in range(12)]
Y_OUT, Y_IN = 124.58, 139.82


def parts():
    P = {}

    def tht(ref, pins):
        P[ref] = [('tht', x, y, d, dr, n, pin) for (x, y, d, dr, n, pin) in pins]

    def smd(ref, x, y, net1, net2, axis='x', pitch=3.0, w=1.2, h=1.6):
        if axis == 'x':
            P[ref] = [('smd', x - pitch / 2, y, w, h, net1, 1), ('smd', x + pitch / 2, y, w, h, net2, 2)]
        else:
            P[ref] = [('smd', x, y - pitch / 2, h, w, net1, 1), ('smd', x, y + pitch / 2, h, w, net2, 2)]

    pins = [(MUX_X[k], Y_OUT, *P254, MUX_NET[nm], nm) for k, nm in enumerate(MUX_PINMAP_OUTER)]
    pins += [(MUX_X[k], Y_IN, *P254, MUX_NET[nm], nm) for k, nm in enumerate(MUX_PINMAP_INNER)]
    tht('U6', pins)

    # U7 GY-BME280 3.3 V, header column at x 17.5 (module body extends +X). bottom->top: SCL SDA VIN GND
    tht('U7', [(17.5, 132.3 + 2.54 * k, *P254, n, nm) for k, (n, nm) in
               enumerate((('SCL', 'SCL'), ('SDA', 'SDA'), ('+3V3', 'VIN'), ('GND', 'GND')))])
    # J2 ESP32 link, JST-PH 5: 3V3 SDA SCL GND FAN_SENSE
    tht('J2', [(25.5 + 2.0 * k, 177.5, *PPH, n, str(k + 1)) for k, n in
               enumerate(('+3V3', 'SDA', 'SCL', 'GND', 'FAN_SENSE'))])

    # U4 bin XGZP carrier (edge-soldered header pins), bottom->top: SDA SCL VCC GND
    tht('U4', [(-4.15, 144.29 + 2.54 * k, *P254, n, nm) for k, (n, nm) in
               enumerate((('SDA2', 'SDA'), ('SCL2', 'SCL'), ('+3V3', 'VCC'), ('GND', 'GND')))])
    # U5 run XGZP carrier header: solder islands - its 4-wire lead goes to the L5 landing
    tht('U5', [(-4.15, 202.79 + 2.54 * k, *P254, f'U5_{nm}', nm) for k, nm in enumerate(('SDA', 'SCL', 'VCC', 'GND'))])

    # L1 cyc_dp SDP810 lead landing (ch3): SDA/SCL beside the corridor, VDD on the 3V3 trunk, GND in the pour
    tht('L1', [(-5.54, 158.3, *PWIRE, 'SDA3', 'SDA'), (-3.0, 158.3, *PWIRE, 'SCL3', 'SCL'),
               (-12.5, 154.5, *PWIRE, '+3V3', 'VDD'), (-13.8, 157.9, *PWIRE, 'GND', 'GND')])
    # L3 encl SDP810 lead landing (ch4): SDA/SCL at the end of the corridor, VDD on a stub off the J2 bus, GND in the pour
    tht('L3', [(3.0, 177.25, *PWIRE, 'SDA4', 'SDA'), (10.62, 177.25, *PWIRE, 'SCL4', 'SCL'),
               (23.0, 175.0, *PWIRE, '+3V3', 'VDD'), (18.2, 175.3, *PWIRE, 'GND', 'GND')])
    # L2 pitot SDP810 lead landing (ch0) + L5 run XGZP lead landing (ch1), beside the mux
    tht('L2', [(-13.97, 143.0, *PWIRE, 'SDA0', 'SDA'), (-11.43, 143.0, *PWIRE, 'SCL0', 'SCL'),
               (-17.8, 144.2, *PWIRE, '+3V3', 'VDD'), (-20.6, 144.2, *PWIRE, 'GND', 'GND')])
    tht('L5', [(-9.2, 145.8, *PWIRE, 'SDA1', 'SDA'), (-6.9, 143.1, *PWIRE, 'SCL1', 'SCL'),
               (-17.8, 147.4, *PWIRE, '+3V3', 'VDD'), (-20.6, 147.4, *PWIRE, 'GND', 'GND')])

    # fan-sense block (+X side, beside J2)
    tht('OK1', [(26.19, 195.0, 1.8, 0.9, 'OK1_A', '1'), (26.19, 197.54, 1.8, 0.9, 'UIS_GND', '2'),
                (33.81, 197.54, 1.8, 0.9, 'GND', '3'), (33.81, 195.0, 1.8, 0.9, 'FAN_SENSE', '4')])
    tht('J3', [(24.5 + 2.54 * k, 210.0, *PWIRE, n, nm) for k, (n, nm) in
               enumerate((('UIS_V+', 'V+'), ('UIS_GND', 'UGND'), ('UIS_CTRL', 'CTRL'), ('UIS_SPARE', 'SPARE')))])

    # ---- SMD, copper side ----
    names = {0: ('R10', 'R11'), 1: ('R16', 'R17'), 2: ('R18', 'R19'), 3: ('R12', 'R13'), 4: ('R14', 'R15')}
    for ch, (ra, rb) in names.items():
        smd(ra, MUX_X[2 * ch], 135.8, '+3V3', f'SDA{ch}', 'y')
        smd(rb, MUX_X[2 * ch + 1], 135.8, '+3V3', f'SCL{ch}', 'y')
    smd('C3', -18.0, 128.0, '+3V3', 'GND', 'y')           # mux VIN
    smd('C2', 23.2, 182.0, 'GND', '+3V3', 'x')            # 10 uF bulk at J2
    smd('R2', 30.0, 189.0, '+3V3', 'FAN_SENSE', 'x')
    smd('C9', 37.0, 190.5, 'FAN_SENSE', 'GND', 'x')
    smd('R1', 24.0, 203.0, 'OK1_A', 'UIS_V+', 'y', pitch=3.2)
    smd('D2', 27.5, 200.5, 'OK1_A', 'UIS_GND', 'x', pitch=3.4, w=1.2, h=1.2)   # 1N4148W: K=OK1_A, A=UIS_GND
    return P


# Hand-drawn trunks (routed before the autorouter fills the rest)
FIXED = {
    '+3V3': [
        [(25.5, 177.5), (25.5, 137.38), (17.5, 137.38)],                   # J2 -> BME VIN (bus, west-most lane)
        [(17.5, 137.38), (15.6, 137.38), (12.6, 134.3), (-15.6, 134.3), (-15.6, 124.58), (-13.97, 124.58)],   # rail -> mux VIN
        [(-15.6, 134.3), (-15.6, 154.5), (-5.9, 154.5), (-5.9, 149.37), (-4.15, 149.37)],  # west trunk -> U4 VCC
        [(25.5, 175.0), (23.0, 175.0)],                                      # -> L3 VDD pad
        [(25.5, 177.5), (25.5, 189.0), (28.5, 189.0)],                       # -> R2
    ],
    'SDA': [[(27.5, 177.5), (27.5, 134.84), (17.5, 134.84)],
            [(17.5, 134.84), (15.8, 134.84), (13.8, 132.8), (-8.89, 132.8), (-8.89, 124.58)]],
    'SCL': [[(29.5, 177.5), (29.5, 132.3), (17.5, 132.3)],
            [(17.5, 132.3), (16.2, 132.3), (15.2, 131.3), (-6.35, 131.3), (-6.35, 124.58)]],
    'SDA4': [[(6.35, 139.82), (6.35, 142.5), (13.9, 142.5), (13.9, 175.2), (3.0, 175.2), (3.0, 177.25)]],
    'SCL4': [[(8.89, 139.82), (8.89, 141.5), (14.9, 141.5), (14.9, 177.25), (10.62, 177.25)]],
    'SDA3': [[(1.27, 139.82), (1.27, 141.0), (-0.85, 143.1), (-0.85, 156.6), (-5.54, 156.6), (-5.54, 158.3)]],
    'SCL3': [[(3.81, 139.82), (3.81, 140.1), (0.15, 143.76), (0.15, 158.3), (-3.0, 158.3)]],
    'SCL2': [[(-1.27, 139.82), (-1.9, 142.0), (-1.9, 146.83), (-4.15, 146.83)]],
    'SDA2': [[(-3.81, 139.82), (-4.15, 141.5), (-4.15, 144.29)]],
    'FAN_SENSE': [[(33.5, 177.5), (33.5, 195.0), (33.81, 195.0)], [(33.5, 189.0), (31.5, 189.0)]],
}
