import sys, json, math, pickle
import numpy as np
from shapely.geometry import box, Point, LineString
from shapely.ops import unary_union
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPoly
import board, geom
from parts import parts, FIXED
from router import Grid, route_all

ORDER = sys.argv[1].split(',') if len(sys.argv) > 1 else None

P = parts()
brd, cuts, holes = board.bottom_board()
minx, miny, maxx, maxy = brd.bounds
grid = Grid((minx - 1, miny - 1, maxx + 1, maxy + 1), 0.2)
outside = box(minx - 5, miny - 5, maxx + 5, maxy + 5).difference(brd)
hard = unary_union([outside.buffer(board.EDGE_CLR), board.keepouts()])
core = unary_union([outside.buffer(0.3)])

pads_by_net = {}
for ref, pl in P.items():
    for p in pl:
        net = p[5]
        if net is None:
            net = f'NC_{ref}_{p[6]}'
        pads_by_net.setdefault(net, []).append((board.pad_geom(p), (p[1], p[2])))
routable = [n for n, pl in pads_by_net.items() if len(pl) > 1 and n != 'GND']
order = ORDER or ['SCL0', 'SDA0', 'SCL2', 'SDA2', 'SCL4', 'SDA4', 'SCL1', 'SDA1', 'SCL3', 'SDA3', 'SDA5', 'SCL5',
                  'OK1_A', 'UIS_GND', 'UIS_V+', 'FAN_SENSE', 'SDA', 'SCL', '+5V', 'XGZP_VCC', '+3V3']
order = [n for n in order if n in routable] + [n for n in routable if n not in order]
best=None
for it in range(4):
    traces, jumpers, fails = route_all(grid, hard, pads_by_net, order, board.TRACE_W, board.CLR, core_hard_geom=core, fixed=FIXED)
    nf=sum(len(p) for n,p in fails)*100+sum(len(j) for j in jumpers.values())
    print(it, 'unrouted pins', nf, [n for n,p in fails], flush=True)
    if best is None or nf<best[0]: best=(nf,traces,fails,list(order),jumpers)
    print('   jumpers', {k:len(v) for k,v in jumpers.items() if v}, flush=True)
    if nf==0: break
    failed=[n for n,p in fails]+[k for k,v in jumpers.items() if v]
    order=failed+[n for n in order if n not in failed]
nf,traces,fails,order,jumpers=best
print('BEST', nf, 'order', order)
print('FAILS:', fails)
pickle.dump({'traces': traces, 'jumpers': jumpers, 'pads_by_net': {k: [c for g, c in v] for k, v in pads_by_net.items()}}, open('/home/claude/pcb/bottom_route.pkl', 'wb'))

# plot
fig, ax = plt.subplots(figsize=(10, 13))
def draw(g, **kw):
    gs = getattr(g, 'geoms', [g])
    for q in gs:
        if q.is_empty: continue
        ax.add_patch(MPoly(np.array(q.exterior.coords), closed=True, **kw))
        for i in q.interiors:
            ax.add_patch(MPoly(np.array(i.coords), closed=True, fc='white', ec='none'))
draw(brd, fc='#f3d9b1', ec='k', lw=0.5)
draw(board.keepouts(), fc='#dddddd', ec='none', alpha=0.6)
cols = plt.cm.tab20(np.linspace(0, 1, 20))
for i, (net, ls) in enumerate(sorted(traces.items())):
    for l in ls:
        x, y = l.xy
        ax.plot(x, y, '-', lw=2.2, color=cols[i % 20], solid_capstyle='round')
for net, pl in pads_by_net.items():
    for g, c in pl:
        draw(g, fc='#b87333' if net != 'GND' else '#555555', ec='k', lw=0.3)
for ref, pl in P.items():
    xs = [p[1] for p in pl]; ys = [p[2] for p in pl]
    ax.text(np.mean(xs), np.mean(ys) + 1.8, ref, fontsize=6, ha='center', color='navy')
for net, jl in jumpers.items():
    for a,b in jl:
        ax.plot([a[0],b[0]],[a[1],b[1]],'--',color='red',lw=1.2); ax.plot([a[0],b[0]],[a[1],b[1]],'o',color='red',ms=4)
for net, pts in fails:
    for x, y in pts:
        ax.plot(x, y, 'rx', ms=10)
ax.set_xlim(minx - 2, maxx + 2); ax.set_ylim(miny - 2, maxy + 2); ax.set_aspect('equal')
ax.set_title('PCB-A bottom board - component-side view (traces are on the underside)')
plt.savefig('/home/claude/pcb/bottom_route.png', dpi=130, bbox_inches='tight')
