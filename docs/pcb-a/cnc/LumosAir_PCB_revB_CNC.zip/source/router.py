import heapq, math
import numpy as np
import shapely
from scipy import ndimage
from shapely.geometry import Point, LineString
from shapely.ops import unary_union


class Grid:
    def __init__(self, bounds, g=0.2):
        self.x0, self.y0, x1, y1 = bounds
        self.g = g
        self.nx = int(math.ceil((x1 - self.x0) / g)) + 1
        self.ny = int(math.ceil((y1 - self.y0) / g)) + 1
        xs = self.x0 + np.arange(self.nx) * g
        ys = self.y0 + np.arange(self.ny) * g
        self.XX, self.YY = np.meshgrid(xs, ys)

    def rc(self, x, y):
        return int(round((y - self.y0) / self.g)), int(round((x - self.x0) / self.g))

    def xy(self, r, c):
        return self.x0 + c * self.g, self.y0 + r * self.g

    def raster(self, geom):
        if geom is None or geom.is_empty:
            return np.zeros(self.XX.shape, bool)
        return shapely.contains_xy(geom, self.XX, self.YY)

    def dist_to(self, mask):
        """distance (mm) from each cell to nearest True cell of mask"""
        if not mask.any():
            return np.full(mask.shape, 1e9)
        return ndimage.distance_transform_edt(~mask) * self.g


def astar(blocked, starts, goals_mask, max_nodes=1500000, land_ok=None, hardmask=None, jcost=45.0, jmax=60):
    goal_idx = np.argwhere(goals_mask)
    if len(goal_idx) == 0:
        return None
    sub = goal_idx[:: max(1, len(goal_idx) // 48)].astype(float)

    def h(r, c):
        return float(np.min(np.hypot(sub[:, 0] - r, sub[:, 1] - c))) * 0.999

    ny, nx = blocked.shape
    INF = 1e18
    dist, prev, pq = {}, {}, []
    for s in starts:
        if blocked[s]:
            continue
        dist[s] = 0.0
        prev[s] = (None, False)
        heapq.heappush(pq, (h(*s), 0.0, s))
    nb = [(-1, 0, 1.0), (1, 0, 1.0), (0, -1, 1.0), (0, 1, 1.0),
          (-1, -1, 1.4142), (-1, 1, 1.4142), (1, -1, 1.4142), (1, 1, 1.4142)]
    n = 0
    while pq:
        f, d, u = heapq.heappop(pq)
        if d > dist.get(u, INF):
            continue
        if goals_mask[u]:
            path = [(u, False)]
            while prev[path[-1][0]][0] is not None:
                p, jumped = prev[path[-1][0]]
                path[-1] = (path[-1][0], jumped)
                path.append((p, False))
            return path[::-1]
        n += 1
        if n > max_nodes:
            return None
        r, c = u
        p = prev[u][0]
        pdir = (r - p[0], c - p[1]) if p is not None else None
        for dr, dc, w in nb:
            v = (r + dr, c + dc)
            if not (0 <= v[0] < ny and 0 <= v[1] < nx) or blocked[v]:
                continue
            nd = d + w + (0.8 if pdir is not None and pdir != (dr, dc) else 0.0)
            if nd < dist.get(v, INF):
                dist[v] = nd
                prev[v] = (u, False)
                heapq.heappush(pq, (nd + h(*v), nd, v))
        # jumper moves (straight, 4 directions) over foreign copper only
        if land_ok is not None and land_ok[u] and not prev[u][1]:
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                seen = False
                for k in range(1, jmax):
                    v = (r + dr * k, c + dc * k)
                    if not (0 <= v[0] < ny and 0 <= v[1] < nx) or hardmask[v]:
                        break
                    if blocked[v]:
                        seen = True
                        continue
                    if not seen:
                        if k > 10:
                            break
                        continue
                    if land_ok[v]:
                        nd = d + k + jcost
                        if nd < dist.get(v, INF):
                            dist[v] = nd
                            prev[v] = (u, True)
                            heapq.heappush(pq, (nd + h(*v), nd, v))
                        break
    return None


def simplify_path(pts):
    """drop collinear grid points"""
    if len(pts) < 3:
        return pts
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        a, b, c = out[-1], pts[i], pts[i + 1]
        d1 = (b[0] - a[0], b[1] - a[1]); d2 = (c[0] - b[0], c[1] - b[1])
        if abs(d1[0] * d2[1] - d1[1] * d2[0]) > 1e-9:
            out.append(b)
    out.append(pts[-1])
    return out


def route_all(grid, hard_block_geom, pads_by_net, order, trace_w, clr, allow_jumpers=True, jpad=1.8, core_hard_geom=None, fixed=None):
    """Returns traces{net:[LineString]}, jumpers{net:[((x,y),(x,y))]}, fails."""
    traces = {n: [] for n in pads_by_net}
    jumpers = {n: [] for n in pads_by_net}
    for n, lines in (fixed or {}).items():
        traces.setdefault(n, []).extend(LineString(l) for l in lines)
    hard = grid.raster(hard_block_geom)
    hard_d = grid.dist_to(hard)
    core = grid.raster(core_hard_geom) if core_hard_geom is not None else hard
    fails = []
    for net in order:
        pads = pads_by_net[net]
        if len(pads) < 2:
            continue
        foreign = []
        for n2, pl in pads_by_net.items():
            if n2 == net:
                continue
            foreign += [g for g, c in pl]
            foreign += [t.buffer(trace_w / 2, 8) for t in traces.get(n2, [])]
            foreign += [Point(p).buffer(jpad / 2, 16) for jj in jumpers.get(n2, []) for p in jj]
        fmask = grid.raster(unary_union(foreign))
        fd = grid.dist_to(fmask)
        blocked = (fd < trace_w / 2 + clr) | (hard_d < trace_w / 2)
        own = grid.raster(unary_union([g for g, c in pads]))
        blocked &= ~own
        land_ok = (fd >= jpad / 2 + clr) & (hard_d >= jpad / 2 + 0.2) if allow_jumpers else None
        fx = [t.buffer(trace_w / 2, 8) for t in traces[net]]
        if fx:
            fxu = unary_union(fx)
            tree_geoms = fx + [g for g, c in pads if g.intersects(fxu)]
            remaining = [i for i, (g, c) in enumerate(pads) if not g.intersects(fxu)]
        else:
            tree_geoms = [pads[0][0]]
            remaining = list(range(1, len(pads)))
        while remaining:
            tree_mask = grid.raster(unary_union(tree_geoms)) & ~blocked
            starts = [tuple(x) for x in np.argwhere(tree_mask)]
            goals = np.zeros_like(blocked)
            for i in remaining:
                gm = grid.raster(pads[i][0]) & ~blocked
                if not gm.any():
                    r, c = grid.rc(*pads[i][1]); gm[r, c] = True
                goals |= gm
            path = astar(blocked, starts, goals, land_ok=land_ok, hardmask=core)
            if path is None:
                fails.append((net, [pads[i][1] for i in remaining]))
                break
            end = path[-1][0]
            hit = None
            for i in remaining:
                if grid.raster(pads[i][0])[end] or grid.rc(*pads[i][1]) == end:
                    hit = i; break
            if hit is None:
                hit = min(remaining, key=lambda i: math.hypot(pads[i][1][0] - grid.xy(*end)[0], pads[i][1][1] - grid.xy(*end)[1]))
            # split into copper runs at jumps
            runs = [[]]
            for (cell, jumped) in path:
                if jumped:
                    a = runs[-1][-1] if runs[-1] else None
                    b = grid.xy(*cell)
                    jumpers[net].append((a, b))
                    tree_geoms += [Point(a).buffer(jpad / 2), Point(b).buffer(jpad / 2)]
                    runs.append([b])
                else:
                    runs[-1].append(grid.xy(*cell))
            runs[-1].append(pads[hit][1])
            for run in runs:
                run = simplify_path(run)
                if len(run) >= 2:
                    ls = LineString(run)
                    traces[net].append(ls)
                    tree_geoms.append(ls.buffer(trace_w / 2, 8))
            tree_geoms.append(pads[hit][0])
            remaining.remove(hit)
    return traces, jumpers, fails
