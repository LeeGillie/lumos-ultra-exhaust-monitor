import math
from shapely.geometry import Polygon, Point, box, LineString, MultiPolygon
from shapely.ops import unary_union
import geom
from parts import parts

EDGE_CLR = 0.8        # copper keep-back from board edges / slots for traces
TRACE_W = 0.6
CLR = 0.40            # min copper-to-copper (different nets)


def bottom_board():
    b = Polygon(geom.BOTTOM_OUTLINE)
    cut = [box(x0, y0, x1, y1) for (x0, x1, y0, y1) in geom.BOTTOM_SLOTS.values()]
    x0, x1, y0, y1 = geom.FLANGE_NOTCH
    cut.append(box(x0, y0, x1, y1))
    holes = [Point(x, y).buffer(geom.MOUNT_DIA / 2, 32) for x, y in geom.MOUNT_HOLES]
    holes += [Point(x, y).buffer(1.35, 24) for x, y in geom.BRACKET_SCREWS]
    return b.difference(unary_union(cut + holes)), cut, holes


def pad_geom(p):
    if p[0] == 'tht':
        _, x, y, d, dr, net, pin = p
        return Point(x, y).buffer(d / 2, 24)
    _, x, y, w, h, net, pin = p
    return box(x - w / 2, y - h / 2, x + w / 2, y + h / 2)


def keepouts():
    """Areas where no trace copper may go (beyond edges): bracket nuts & mount-hole rings."""
    k = [Point(x, y).buffer(3.0, 24) for x, y in geom.BRACKET_SCREWS]
    k += [Point(x, y).buffer(3.2, 24) for x, y in geom.MOUNT_HOLES]
    return unary_union(k)
